package project.controller;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.NotSerializableException;
import java.util.ArrayList;
import java.util.InputMismatchException;

import javax.swing.JOptionPane;

import project.listeners.ManagementListenable;
import project.listeners.ViewListenable;
import project.model.Management;
import project.model.exceptions.ExamNotCreatedYet;
import project.model.exceptions.ExamSizeTooBigException;
import project.model.exceptions.IdOutOfRangeException;
import project.model.exceptions.NotAmericanQuestionException;
import project.model.exceptions.QuestionAlreadyExists;
import project.view.View;

public class Controller implements ManagementListenable, ViewListenable{
	private Management theModel;
	private View theView;
	
	
	public Controller(Management theModel, View theView) {
		this.theModel = theModel;
		this.theView = theView;
		
		theModel.registerListener(this);
		theView.registerListener(this);
		
		startManagement();
	}



	//View methods
	@Override
	public ArrayList<String> viewShowAllQuestions(int startingIndex, int jumpRange) {
		return theModel.getQuestionsString(startingIndex, jumpRange);
	}

	@Override
	public int viewGetCapacity() {
		return this.theModel.getQuestionsSize();
	}
	
	@Override
	public int viewGetExamSize() {
		return this.theModel.getExamQuestionsSize();
	}

	@Override
	public void viewAddQuestion(String text, String type) {
		theModel.addQuestionFromUser(text, type);	
	}

	
	@Override
	public void viewAddAnswer(String text) {
		theModel.addAnswerFromUser(text);
	}

	@Override
	public void viewAddAnswerAmerican(String text, boolean answerBoolean) {
		theModel.addAnswerFromUser(text, answerBoolean);
	}
	
	@Override
	public boolean viewIsAmerican(int index) {
		return this.theModel.isAmerican(index);
	}
	
	public boolean viewIsCurrentQuestionAmerican() {
		int currentQuestion = this.theModel.getQuestionsSize()-1;//gets the currentQuestion
		return viewIsAmerican(currentQuestion); //returns if the current question is american or not
	}
	

	@Override
	public void viewChangeQuestion(String text, int currentIndex) {
		theModel.updateWording(text, currentIndex);
		
	}

	@Override
	public void viewChangeAnswer(String answerText, int currentIndex) {
		theModel.changeAnswer(currentIndex, answerText);
		
	}

	@Override
	public void viewChangeAnswerAmerican(String text, int currentIndex, int answerIndex, boolean answerBoolean) {
		theModel.changeAnswer(currentIndex, answerIndex, text, answerBoolean);
		
	}
	
	public void viewGiveIndex(String id) {
		int index = getIndex(id);
		if (index != -1) {
			theView.updateGiveIndex(index);
		}
	}
	
	
	@Override
	public void viewAddQuestionToExam(String id) {
		int currentIndex = this.getIndex(id);
		if (currentIndex != -1) {
			try {
				theModel.checkAndAddQuestionForExam(currentIndex);//checks questions and if viable adds them
				theView.showAddedExamQuestionSucessfully(currentIndex);
			} catch (CloneNotSupportedException e) {
				
			} catch (QuestionAlreadyExists e) {
				theView.showQuestionAlreadyExists();
			} catch (ExamSizeTooBigException e) {
				theView.showExamSizeMaximum();
			}
		}
		
	}

	@Override
	public void viewInitializeExam() {
		theModel.createExam();
	}

	@Override
	public void viewAddAnswerToExam(int currentIndex, int answerIndex) {
		theModel.addAnswerToExam(currentIndex, answerIndex);
		
	}
	
	public boolean viewIsCurrentExamQuestionAmerican() {
		return theModel.isCurrentExamQuestionAmerican();
	}
	
	public void viewFinishManualExam() {
		theModel.sortQuestionsArray();
		theView.finishExam();
	}

	@Override
	public ArrayList<String> viewShowExamQuestions(int startingIndex, int jumpSize) {
		return theModel.getCurrentExamQuestions(startingIndex, jumpSize);
	}
	
	
	@Override
	public void viewMakeRandomizedExam(String examSize) {
		try {
			int examSizeConverted = Integer.parseInt(examSize);
			theModel.createRandomizedExam(examSizeConverted);
			theView.finishExam();
		} catch (NumberFormatException e) {
			theView.showWrongIdInput();
		} catch (ExamSizeTooBigException e) {
			theView.showExamTooBig();
		} catch (CloneNotSupportedException e) {
			//only formal, the cloned item can be cloned
		} catch (IdOutOfRangeException e) {
			//not relevant to this case, generate random number already makes sure id is in-range
		}
	}

	@Override
	public void viewCopyExam(){
		try {
			theModel.cloneExam();
			theView.showExamClonedSucessfully();
		} catch (CloneNotSupportedException e) {
			//only formal, it only tries to clone something cloneable
		} catch (ExamNotCreatedYet e) {
			theView.showExamNotCreated();
		}
		
	}

	@Override
	public void viewSaveExam()  {
			try {
				theModel.saveExam();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
	
	@Override
	public void viewRemoveAnswerOpen(int currentIndex) {
		theModel.deleteAnswer(currentIndex);
		
	}
	
	@Override
	public void viewRemoveAnswerAmerican(int currentIndex, int answerIndex) {
		theModel.deleteAnswer(currentIndex, answerIndex);
	}
	
	@Override
	public void viewSetAmericanAnswers(int index) {
		try {
			theView.setAmericanCmbBox(theModel.getAnswerSet(index));
		} catch (NotAmericanQuestionException e) {
			theView.showNotAmericanQuestion();//most likely it won't reach here because of previous checks
			//but for example if someone wanted to get the answer set from view and sent a bad index the check is needed
		} catch (CloneNotSupportedException e) {
			//formal, getAnswerSet only tries to clone a cloneable object
		}
		
	}
	
	//Model methods

	@Override
	public void modelUpdateTextIsEmpty() {
		theView.showTextIsEmpty();	
	}

	@Override
	public void modelUpdateAddedQuestion(String type) {
		theView.showAddedQuestionSucessfully();
	}

	@Override
	public void modelTextAlreadyExists() {
		theView.showTextAlreadyExists();
	}

	
	@Override
	public void modelUpdateExamAnswerAdded() {
		theView.showAddedExamAnswerSuccessfully();
	}
	
	
	@Override
	public void modelUpdateAnswerChanged() {
		theView.showAnswerUpdatedSuccessfully();
	}
	
	@Override
	public void modelUpdateQuestionChanged() {
		theView.showQuestionUpdatedSuccessfully();
	}
	

	@Override
	public void modelUpdateAnswerRemoved() {
		theView.showAnswerDeletedSucessfully();
	}
	
	//Controller methods
	
	private void startManagement() {
		try {
			theModel.loadQuestionsArray(); //tries to load file
			theModel.setStartingId();
		} catch (Exception e) {
			theModel.initializeQuestions(); //if file doesn't exist or serial num isn't right then loads hardcoded
		} 
		
	}
	
	public int getIndex(String id) {
		try {
			int currentId = Integer.parseInt(id);//if user entered input which is not a number will throw an exception
			int index = theModel.getQuestionIndexById(currentId);//gets index according to Id
			return index;
		} catch (NumberFormatException e) {
			this.theView.showWrongIdInput();
		} catch (IdOutOfRangeException e) {
			this.theView.showIdOutOfRange();
		}
		return -1;
	}


	@Override
	public void modelUpdateAnswerAdded() {
		theView.showAddedAnswerSuccessfully();	
	}


	
	@Override
	public void saveQuestions() {
		try {
			theModel.saveQuestionsArray();
		} catch (Exception e) {
			//Shouldn't have exception since we're saving the array to a file we make
		} 
		
	}

	@Override
	public void viewAddLastTwoAnswers() {
		theModel.addLastTwoAnswersForExamQuestion();
	}

	
	
}
