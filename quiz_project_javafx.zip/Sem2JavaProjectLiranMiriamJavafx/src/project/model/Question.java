package project.model;

import java.io.PrintWriter;
import java.io.Serializable;

public abstract class Question implements Serializable{
	protected static int globalId = 1;
	protected String text;
	protected int questionId; 
	
	public Question(String text) {
		this.text = text;
		this.questionId = globalId++;
	}
	
	public Question(Question other) {
		this.text = other.text;
		this.questionId = other.questionId;
	}
	
	public String getText() {
		return this.text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public static int getGlobalId(){
		return globalId;
	}
	
	public abstract void saveAnswers(PrintWriter pw);
	
	public abstract int countLetters();
	
	@Override
	public boolean equals(Object q) {
		if (!(q instanceof Question)) {
			return false;
		}
		Question testQuestion = (Question)q;
		if (this.questionId != testQuestion.questionId) {
			return false;
		}
		if (!this.text.equals(testQuestion.text)) {
			return false;
		}
		return true;
	}
	
	@Override
	public String toString() {
		return getClass().getSimpleName() + " - Question ID is " + questionId + " the question is : \n" + text + "\n";
	}

	public static void initializeId(int idSize) {
		globalId = idSize + 1;
	}
}
