package project.model;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Objects;

public class Set<T> implements Cloneable, Serializable{
	private T[] arr;
	private int currentSize;

	
	@SuppressWarnings("unchecked")
	public Set(int size) {
		this.arr = (T[]) new Object[size];
		// currentSize is 0 by default
	}

	public boolean add(T element) {
		
		for (int i = 0; i < currentSize; i++) {
			if (element.equals(arr[i])) {
				return false;
			}
		}
		
		if (currentSize == arr.length) {
			if (this.arr.length == 0) {
				this.arr = Arrays.copyOf(arr, 2);
			} else {
				this.arr = Arrays.copyOf(arr, this.currentSize * 2);
			}
		}

		arr[currentSize++] = element;
		return true;
	}

	public T getArrElement(int index) {
		return arr[index];
	}

	public int getCurrentSize() {
		return currentSize;
	}

	public int getLength() {
		return arr.length;
	}

	@Override
	public boolean equals(Object obj) {
		if (!(obj instanceof Set)) {
			return false;
		}
		Set<?> otherSet = (Set<?>) obj;

		if (otherSet.currentSize != this.currentSize) {
			return false;
		}
		for (int i = 0; i < this.currentSize; i++) {
			if (!this.arr[i].equals(otherSet.arr[i])) {
				return false;
			}
		}

		return true;

	}

	public boolean remove(int index) {
		this.arr[index] = null;
		for (int i = 0; i < currentSize - 1; i++) {
			if (this.arr[i] == null) {
				this.arr[i] = this.arr[i + 1];
				this.arr[i + 1] = null;
			}
		}

		currentSize--;
		return false;
	}

	@Override
	public Set<T> clone() throws CloneNotSupportedException {
		Set<T> S = (Set<T>) super.clone();
		T[] newArr = Arrays.copyOf(this.arr, currentSize);
		S.arr = newArr;

		return (Set<T>)S;
	}

	@Override
	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("[");
		for (int i = 0; i < this.currentSize; i++) {
			sb.append(arr[i]).append(",\t");
		}
		sb.append("]\n");

		return sb.toString();
	}

	public void set(int index, T newAnswer) {
		arr[index] = newAnswer;
	}

	public boolean contains(T arrElement) {
		for (int i = 0; i < this.currentSize; i++) {
			if (this.arr[i].equals(arrElement)) {
				return true;
			}
		}
		return false;
	}

}
