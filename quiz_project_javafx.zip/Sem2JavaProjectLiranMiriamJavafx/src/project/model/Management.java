package project.model;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;

import project.listeners.ManagementListenable;
import project.model.exceptions.ExamNotCreatedYet;
import project.model.exceptions.ExamSizeTooBigException;
import project.model.exceptions.IdOutOfRangeException;
import project.model.exceptions.NotAmericanQuestionException;
import project.model.exceptions.QuestionAlreadyExists;

@SuppressWarnings("serial")
public class Management implements Serializable {
	private ArrayList<ManagementListenable> allListeners;
	private ArrayList<Question> questions;
	private Exam currentExam;

	public Management() {
		this.allListeners = new ArrayList<ManagementListenable>();

		this.questions = new ArrayList<Question>();// creates an array with size 0
	}

	public void initializeQuestions() {
		int tempIndex;

		addQuestionFromSystem(
				"Name the Korean red chili paste, which is used in various dishes such as tteokbokki and bibimbap",
				"Gochujang");
		addQuestionFromSystem("What country is the origin of Pho?", "Vietnam");
		addQuestionFromSystem("What is a primary ingredient of Takoyaki?", "Octopus");
		addQuestionFromSystem("Complete the sentence: \"Nearly every Malay meal is served with...\"", "Rice");
		addQuestionFromSystem("Which toast do Singaporeans eat for breakfast?", "Kaya toast");

		addQuestionFromSystem("The popular form of yeast-leavened bread cooked in a tandoor");
		tempIndex = this.questions.size() - 1;// last question index
		addAnswerFromSystem(getQuestion(tempIndex), "Chapati", false);
		addAnswerFromSystem(getQuestion(tempIndex), "Bao Bun", false);
		addAnswerFromSystem(getQuestion(tempIndex), "Naan", true);
		addAnswerFromSystem(getQuestion(tempIndex), "Biscotti", false);
		addAnswerFromSystem(getQuestion(tempIndex), "Condemsed milk bread", false);
		addAnswerFromSystem(getQuestion(tempIndex), "Garlic bread", false);

		addQuestionFromSystem("Which country is the origin of adobo chicken");
		tempIndex = this.questions.size() - 1;
		addAnswerFromSystem(getQuestion(tempIndex), "Thailand", false);
		addAnswerFromSystem(getQuestion(tempIndex), "Philippines", true);
		addAnswerFromSystem(getQuestion(tempIndex), "Indonesia", false);
		addAnswerFromSystem(getQuestion(tempIndex), "South Korea", false);
		addAnswerFromSystem(getQuestion(tempIndex), "Japan", false);
		addAnswerFromSystem(getQuestion(tempIndex), "Malaysia", false);
		addAnswerFromSystem(getQuestion(tempIndex), "Laos", false);
		addAnswerFromSystem(getQuestion(tempIndex), "Cambodia", false);

		addQuestionFromSystem("Which ingredient is not used in Tom Yam?");
		tempIndex = this.questions.size() - 1;
		addAnswerFromSystem(getQuestion(tempIndex), "Thai chilies", false);
		addAnswerFromSystem(getQuestion(tempIndex), "Lemongrass", false);
		addAnswerFromSystem(getQuestion(tempIndex), "Green curry", true);
		addAnswerFromSystem(getQuestion(tempIndex), "Galangal", false);
		addAnswerFromSystem(getQuestion(tempIndex), "Kaffir lime leaves", false);
		addAnswerFromSystem(getQuestion(tempIndex), "Cilantro", false);
		addAnswerFromSystem(getQuestion(tempIndex), "Fish Sauce", false);
		addAnswerFromSystem(getQuestion(tempIndex), "Parmesan", true);

		addQuestionFromSystem("What is considered to be a traditional mooncake filling?");
		tempIndex = this.questions.size() - 1;
		addAnswerFromSystem(getQuestion(tempIndex), "Sweet potato paste", false);
		addAnswerFromSystem(getQuestion(tempIndex), "Lotus seed paste", true);
		addAnswerFromSystem(getQuestion(tempIndex), "Chia paste", false);
		addAnswerFromSystem(getQuestion(tempIndex), "Red bean paste", true);
		addAnswerFromSystem(getQuestion(tempIndex), "Black bean paste", false);
		addAnswerFromSystem(getQuestion(tempIndex), "Cashew paste", false);

		addQuestionFromSystem("Which of the next is an Indonesian dish?");
		tempIndex = this.questions.size() - 1;
		addAnswerFromSystem(getQuestion(tempIndex), "Nasi goreng", true);
		addAnswerFromSystem(getQuestion(tempIndex), "Mochi", false);
		addAnswerFromSystem(getQuestion(tempIndex), "Jjajangmyeong", false);
		addAnswerFromSystem(getQuestion(tempIndex), "Kimbap", false);
		addAnswerFromSystem(getQuestion(tempIndex), "Ha gow dim sum", false);
		addAnswerFromSystem(getQuestion(tempIndex), "Kimchi", false);
		addAnswerFromSystem(getQuestion(tempIndex), "Dhal", false);

	}

	public void registerListener(ManagementListenable l) {
		allListeners.add(l);
	}

	// Add question

	public void addQuestionToArray(Question newQuestion) {
		this.questions.add(newQuestion);
	}

	public void addQuestionFromSystem(String name, String answer) {
		Question temp = new OpenQuestion(name, answer);
		addQuestionToArray(temp);
	}

	public void addQuestionFromSystem(String name) {
		Question temp = new AmericanQuestion(name);
		addQuestionToArray(temp);
	}

	public void addQuestionFromUser(String text, String type) {
		int questionType = type.equals("American Question") ? 1 : 2; // for check if question exsits by text

		if (text.isBlank()) {
			fireTextIsEmpty();
		} else if (checkIfQuestionExistsByText(text, questionType)) {
			fireTextAlreadyExists();
		} else if (type.equals("American Question")) {
			this.questions.add(new AmericanQuestion(text));
			fireAddedQuestion(type);
		} else {
			this.questions.add(new OpenQuestion(text));
			fireAddedQuestion(type);
		}

	}

	// Add Answer

	public boolean addAnswerFromSystem(Question tempQuestion, String answerText, boolean correctAnswer) {
		if (((AmericanQuestion) tempQuestion).addAnswerToArray(answerText, correctAnswer)) {
			return false;
		}

		return true;
	}

	public void addAnswerFromUser(String answer) {// Open question
		if (answer.isBlank()) {
			fireTextIsEmpty();
		} else {
			((OpenQuestion) questions.get(this.questions.size() - 1)).setAnswer(answer);
			fireAnswerAdded();
		}
	}

	public void addAnswerFromUser(String answer, boolean answerBoolean) {// American question
		AmericanQuestion theQuestion = (AmericanQuestion) this.questions.get(getQuestionsSize() - 1);

		if (answer.isBlank()) {
			fireTextIsEmpty();

		} else if (!(theQuestion.addAnswerToArray(answer, answerBoolean))) {
			fireTextAlreadyExists();
		} else {
			fireAnswerAdded();
		}
	}

	public void addAnswerToExam(int originalIndex, int answerIndex) { // only american questions use this, open
																		// questions
																		// just add their default answer
		AmericanQuestion temp = (AmericanQuestion) this.questions.get(originalIndex); // gets current question from
																						// management
		String answerText = temp.getAnswerText(answerIndex);

		if (this.currentExam.checkIfAnswerExistsByText(answerText)) {
			fireTextAlreadyExists();
			return;
		}

		boolean answerBoolean = temp.getCorrectAnswerBoolean(answerIndex); // gets true/false
		this.currentExam.addAnswer(answerText, answerBoolean); // adds answer to exam
		fireExamAnswerAdded();
	}

	// Add Question
	public void updateWording(String text, int currentIndex) {

		if (text.isBlank()) {
			fireTextIsEmpty();
			return;
		}

		int questionType;
		if (questions.get(currentIndex) instanceof AmericanQuestion) {
			questionType = 1;
		} else {
			questionType = 2;
		}

		if (checkIfQuestionExistsByText(text, questionType)) {// Checks the question text exists and is of the same type
			fireTextAlreadyExists();
			return;
		}

		this.questions.get(currentIndex).setText(text); // Sets new Question text
		fireQuestionChanged();

	}

	// Change answer

	public void changeAnswer(int index, int answerNum, String newAnswer, boolean answerBoolean) {// american question
		if (newAnswer.isBlank()) {
			fireTextIsEmpty();
		}

		((AmericanQuestion) questions.get(index)).setAnswer(answerNum, newAnswer, answerBoolean);
		fireAnswerChanged();
	}

	public void changeAnswer(int index, String newAnswer) {// open question
		if (newAnswer.isBlank()) {
			fireTextIsEmpty();
			return;
		}

		((OpenQuestion) questions.get(index)).setAnswer(newAnswer);
		fireAnswerChanged();

	}

	// Delete Answer

	public void deleteAnswer(int index, int answerNumber) { // for american question
		((AmericanQuestion) questions.get(index)).setAnswer(answerNumber, null, false);
		fireAnswerRemoved();
	}

	public void deleteAnswer(int currentIndex) { // for open question
		((OpenQuestion) questions.get(currentIndex)).removeAnswer();
		fireAnswerRemoved();
	}

	// Gets

	public ArrayList<String> getQuestionsString(int currentIndex, int jumpRange) {
		ArrayList<String> listOfQuestions = new ArrayList<String>();

		for (int i = currentIndex; i < currentIndex + jumpRange && i < this.questions.size(); i++) {
			listOfQuestions.add(this.questions.get(i).toString()); // adds question text to arraylist
																	// depends on jump range from controller
		}

		return listOfQuestions;
	}

	public Set<String> getAnswerSet(int index) throws NotAmericanQuestionException, CloneNotSupportedException {
		if (!(this.questions.get(index) instanceof AmericanQuestion)) {
			throw new NotAmericanQuestionException();// if answer not american throw exception
		}
		AmericanQuestion temp = (AmericanQuestion) this.questions.get(index);
		return temp.getAnswerSet(); // return the answer set from question
	}

	public Question getQuestion(int index) {
		return questions.get(index);
	}

	public int getQuestionsSize() {
		return this.questions.size();
	}

	public int getQuestionIndexById(int currentId) throws IdOutOfRangeException {

		for (int i = 0; i < questions.size(); i++) {
			if (currentId == questions.get(i).questionId) {
				return i;
			}
		}

		throw new IdOutOfRangeException();
	}

	public int getExamQuestionsSize() {
		return this.currentExam.getSize();
	}

	public void exchangeAnswersArray(Set<String> answersArray, ArrayList<Boolean> correctAnswersArray) {
		AmericanQuestion temp = (AmericanQuestion) currentExam.getCurrentExamQuestion();
		temp.setAnswersArray(answersArray, correctAnswersArray);// takes the two arrays we created
		// exchanges the questions arrays with them
		addLastTwoAnswersToArray(temp); // adds "no answer is correct" and "more than one answer is correct"
	}

	// Logic and checks

	public boolean checkIfQuestionExistsByText(String currentText, int choice) {// this function question receives
																				// either 1 or 2
		// depending if the question is American or Open, and returns false if the
		// choice wasn't 1 or 2
		// it then checks if the text that the user entered is similar to another, but
		// only if the question type is similar
		// this allows us to have 2 questions with the similar text but different types

		if (choice == 1) {
			for (int i = 0; i < this.questions.size(); i++) {
				if (currentText.equals(questions.get(i).getText()) && questions.get(i) instanceof AmericanQuestion) {
					return true;
				}
			}
		}
		if (choice == 2) {
			for (int i = 0; i < this.questions.size(); i++) {
				if (currentText.equals(questions.get(i).getText()) && questions.get(i) instanceof OpenQuestion) {
					return true;
				}
			}
		}

		return false;
	}

	public int checkNumOfCorrectAnswers(Question question) {
		AmericanQuestion q = (AmericanQuestion) question;
		return q.getNumOfCorrectAnswers();

	}

	public boolean isAmerican(int index) {
		if (this.questions.get(index) instanceof AmericanQuestion) {
			return true;
		}
		return false;
	}

	public void createRandomizedExam(int examSize)
			throws ExamSizeTooBigException, CloneNotSupportedException, IdOutOfRangeException {
		new RandomizeExam(this, examSize); //constructor randomizes current exam
	}

	// Methods that deal with exam

	public void checkAndAddQuestionForExam(int currentIndex)
			throws CloneNotSupportedException, QuestionAlreadyExists, ExamSizeTooBigException {
		if (this.questions.size() == this.currentExam.getSize()) {
			throw new ExamSizeTooBigException();
		}
		if (this.currentExam.checkIfQuestionExistsByText(this.questions.get(currentIndex).getText())) {
			throw new QuestionAlreadyExists();
		}

		Question temp = this.questions.get(currentIndex);
		if (temp instanceof AmericanQuestion) {
			AmericanQuestion tempAmq = (AmericanQuestion) temp;
			this.addQuestionToExam(tempAmq);
			return;
		}

		OpenQuestion tempOp = (OpenQuestion) temp;
		this.addQuestionToExam(tempOp);

	}

	public void addQuestionToExam(AmericanQuestion newQuestion) throws CloneNotSupportedException {
		AmericanQuestion temp = newQuestion.clone();
		temp.setAnswersClear();
		this.currentExam.addQuestion(temp);

	}

	public void addQuestionToExam(OpenQuestion newOpQuestion) throws CloneNotSupportedException {
		Question temp = newOpQuestion.clone();
		this.currentExam.addQuestion(temp);

	}

	public ArrayList<String> getCurrentExamQuestions(int startingIndex, int jumpSize) {
		ArrayList<String> temp = this.currentExam.getExamQuestions(startingIndex, jumpSize);
		return temp;
	}

	public void createExam() {
		this.currentExam = new Exam();
	}

	public Exam getcurrentExam() {
		return this.currentExam;
	}

	public void cloneExam() throws CloneNotSupportedException, ExamNotCreatedYet {
		if (this.currentExam == null) {
			throw new ExamNotCreatedYet();
		}
		this.currentExam = this.currentExam.clone();
	}

	public boolean doesExamExist() {
		if (this.currentExam == null) {
			return false;
		}
		return true;
	}

	public void sortQuestionsArray() {
		this.currentExam.sortExamByStringLength();
	}

	public boolean isCurrentExamQuestionAmerican() {
		if (this.currentExam.getCurrentExamQuestion() instanceof AmericanQuestion) {
			return true;
		}

		return false;
	}

	// Object methods

	@Override
	public boolean equals(Object o) {
		if (!(o instanceof Management)) {
			return false;
		}
		Management m = (Management) o;
		if (this.questions.size() != m.questions.size()) {
			return false;
		}

		return this.questions.equals(m);
	}

	@Override
	public String toString() {
		StringBuffer sb = new StringBuffer();

		for (int i = 0; i < this.questions.size(); i++) {
			sb.append(i + 1).append(") ").append(this.questions.get(i)).append("\n");
		}

		return sb.toString();
	}

	public int getAnswersSize(AmericanQuestion newQuestion) {
		return newQuestion.getCurrentSize();
	}

	public int howManyQuestionsViable() {
		int counter = 0;
		for (int i = 0; i < this.questions.size(); i++) {
			if (this.questions.get(i) instanceof AmericanQuestion
					&& ((AmericanQuestion) this.questions.get(i)).checkIfThereAreEnoughFalseAnswers()// returns true if
																										// there are 3
																										// or more false
																										// answers
					&& ((AmericanQuestion) this.questions.get(i)).getCurrentSize() >= 4) {// checks if there are atleast
																							// 4 questions
				counter++;
			} else if (this.questions.get(i) instanceof OpenQuestion) {
				counter++;
			}
		}

		return counter;
	}

	// Methods for finishing arrays

	public static void addLastTwoAnswersToArray(AmericanQuestion newQuestion) {
		int numOfCorrectAnswers = newQuestion.getNumOfCorrectAnswers();// Returns how many true answers there are in the
																		// array

		if (numOfCorrectAnswers > 1) {
			newQuestion.setArrayToFalse();
			String someAnswers = "More than one answer is correct";
			newQuestion.addAnswerToArray(someAnswers, true);
			String noAnswer = "No answer is correct";
			newQuestion.addAnswerToArray(noAnswer, false);
		} else if (numOfCorrectAnswers == 0) {
			String someAnswers = "More than one answer is correct";
			newQuestion.addAnswerToArray(someAnswers, false);
			String noAnswer = "No answer is correct";
			newQuestion.addAnswerToArray(noAnswer, true);
		}

		else {
			String someAnswers = "More than one answer is correct";
			newQuestion.addAnswerToArray(someAnswers, false);
			String noAnswer = "No answer is correct";
			newQuestion.addAnswerToArray(noAnswer, false);
		}
	}

	// Save and load methods

	public void saveExam() throws FileNotFoundException {
		String s = "SavedExams/Exams" + LocalDate.now().toString() + ".txt";// adds text before the date we get
		String fileName = s.replace("-", "_");// swaps - with _
		this.currentExam.saveQuestions(fileName);
		s = "SavedExams/Solution_" + LocalDate.now().toString() + ".txt";
		fileName = s.replace("-", "_");
		this.currentExam.saveAnswers(fileName);

	}

	public void saveQuestionsArray() throws FileNotFoundException, IOException {
		ObjectOutputStream outFile = new ObjectOutputStream(new FileOutputStream("Questions Array.dat"));
		outFile.writeObject(this.questions);
		outFile.close();
	}

	public void loadQuestionsArray() throws FileNotFoundException, IOException, ClassNotFoundException {
		ObjectInputStream inFile = new ObjectInputStream(new FileInputStream("Questions Array.dat"));
		this.questions = (ArrayList<Question>) inFile.readObject();
		inFile.close();
	}

	public void setStartingId() { // needs this to jump start questions from binary file
		Question.initializeId(this.questions.size());
	}

	public void addLastTwoAnswersForExamQuestion() {
		AmericanQuestion temp = (AmericanQuestion) this.currentExam.getCurrentExamQuestion(); // case only starts from
																								// american question
																								// so there's no reason
																								// to check it again
		this.addLastTwoAnswersToArray(temp);
	}

	// Fire

	public void fireTextIsEmpty() {
		allListeners.get(0).modelUpdateTextIsEmpty();
	}

	public void fireTextAlreadyExists() {
		allListeners.get(0).modelTextAlreadyExists();
	}

	public void fireAddedQuestion(String type) {
		allListeners.get(0).modelUpdateAddedQuestion(type);
	}

	public void fireAnswerAdded() {
		allListeners.get(0).modelUpdateAnswerAdded();
	}

	public void fireAnswerRemoved() {
		allListeners.get(0).modelUpdateAnswerRemoved();
	}

	public void fireExamAnswerAdded() {
		allListeners.get(0).modelUpdateExamAnswerAdded();
	}

	public void fireQuestionChanged() {
		allListeners.get(0).modelUpdateQuestionChanged();
	}

	public void fireAnswerChanged() {
		allListeners.get(0).modelUpdateAnswerChanged();
	}

}
