package project.model;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;


public class Exam implements Cloneable{
	private ArrayList<Question> examQuestions;

	public Exam() {
		this.examQuestions = new ArrayList<Question>();
	}
	
	public Exam clone() throws CloneNotSupportedException{
		return (Exam) super.clone();
	}

	public void addQuestion(Question newQuestion) {
			this.examQuestions.add(newQuestion); 
	}

	public void showTheQuestions() {
		for (int i = 0; i < this.examQuestions.size(); i++) {
			System.out.println(examQuestions.get(i));
		}

	}

	public Question getCurrentExamQuestion() {
		return examQuestions.get(examQuestions.size() - 1);
	}

	public boolean checkIfQuestionExistsByText(String text) {
		for (int i = 0; i < examQuestions.size(); i++) {
			if (text.equals(examQuestions.get(i).text)) {
				return true;
			}
		}

		return false;
	}

	public void saveQuestions(String fileName) throws FileNotFoundException  {
		File f = new File(fileName);
		PrintWriter pw = new PrintWriter(f);
		
		pw.println(examQuestions.size());
		for (int i = 0; i < examQuestions.size(); i++) {
			pw.println(this.examQuestions.get(i).getText());
		}
		pw.close();
	}
	
	public void saveAnswers(String fileName) throws FileNotFoundException {
		PrintWriter pw = new PrintWriter(new File(fileName));
		
		for (int i = 0; i < examQuestions.size(); i++) {
			this.examQuestions.get(i).saveAnswers(pw);
		}
		pw.close();
		
	}

	@Override
	public boolean equals(Object other) {
		if (!(other instanceof Exam)) {
			return false;
		}
		Exam e = (Exam) other;
		if (this.examQuestions.size() != e.examQuestions.size()) {
			return false;
		}
		for (int i = 0; i < this.examQuestions.size(); i++) {
			if (!this.examQuestions.contains(e.examQuestions.get(i))) {
				return false;
			}
		}
		return true;
	}

	@Override
	public String toString() {
		StringBuffer sb = new StringBuffer();
		sb.append("In this exam there are ").append(examQuestions.size()).append(" questions: \n");
		for (int i = 0; i < examQuestions.size(); i++) {
			sb.append(i + 1).append(") ").append(examQuestions.get(i)).append("\n");
		}
		return sb.toString();
	}

	public void organizeExamArray() {
		for (int i = 1; i < examQuestions.size(); i++) {
			for (int j = i; j > 0 && this.examQuestions.get(j - 1).getText()
					.compareToIgnoreCase(this.examQuestions.get(j).getText()) > 0; j--) {
				// Checks if one text is bigger than the other decides where to move it using
				// insertion sort
				Question temp = examQuestions.get(j);
				this.examQuestions.set(j, this.examQuestions.get(j - 1));
				this.examQuestions.set(j - 1, temp);
			}
		}

	}

	public void sortExamByStringLength() {
		this.examQuestions.sort(new CompareByTextLength());
	}

	public void loadExam(Scanner examNameScanner, Scanner solutionNameScanner){
		int questionSize = Integer.parseInt(examNameScanner.nextLine());
		
		
		for (int i = 0; i < questionSize; i++) {
			int solutionSize = Integer.parseInt(solutionNameScanner.nextLine());
			String questionName = examNameScanner.nextLine();
			
			if (solutionSize == 1) {
				Question temp = new OpenQuestion(questionName, solutionNameScanner.nextLine());
				addQuestion(temp);
			}
			else {
				Question amTemp = new AmericanQuestion(questionName);
				for (int j = 0; j < solutionSize; j++) {
					String answerText = solutionNameScanner.nextLine();
					boolean answerBoolean = Boolean.parseBoolean(solutionNameScanner.nextLine()); 
					((AmericanQuestion)amTemp).addAnswerToArray(answerText, answerBoolean);
				}
				addQuestion(amTemp);
			}
		}
		
		
	}

	public int getSize() {
		return this.examQuestions.size();
	}

	public boolean checkIfAnswerExistsByText(String answerText) {
		
		return ((AmericanQuestion)this.examQuestions.get(this.examQuestions.size()-1)).checkAnswersArray(answerText);

	}

	public void addAnswer(String answerText, boolean answerBoolean) {
		((AmericanQuestion)this.examQuestions.get(this.examQuestions.size()-1)).addAnswerToArray(answerText, answerBoolean);
		
	}

	public ArrayList<String> getExamQuestions(int startingIndex, int jumpSize) {
		ArrayList<String> temp = new ArrayList<String>();
		for (int i = startingIndex; i < this.examQuestions.size() && i < startingIndex + jumpSize; i++) {
			temp.add(this.examQuestions.get(i).toString());
		}
		return temp;
	}



}
