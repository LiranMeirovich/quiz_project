package project.model;

import java.util.ArrayList;

import project.model.exceptions.ExamSizeTooBigException;
import project.model.exceptions.IdOutOfRangeException;

public class RandomizeExam {
	private Management currentManagement;

	public RandomizeExam(Management currentManagement, int examSize) throws CloneNotSupportedException, ExamSizeTooBigException, IdOutOfRangeException {
		this.currentManagement = currentManagement;
		
		randomizeExam(examSize);
	}

	public void randomizeExam(int examSize) throws CloneNotSupportedException, ExamSizeTooBigException, IdOutOfRangeException {
		if (this.currentManagement.howManyQuestionsViable() < examSize) {
			throw new ExamSizeTooBigException();
		}

		this.currentManagement.createExam(); //only creates new exam if exam size is correct

		for (int i = 0; i < examSize; i++) {
			boolean addedQuestion = false;
			while (!addedQuestion) {
				int randomId = generateRandomNum(Question.getGlobalId() - 1, 1);// Generates number
																							// with max range of
																							// globalId
				
				if (this.addQuestionToArrayAndPickRandomAnswers(randomId)) {//if it manages to add an answer returns true
					addedQuestion = true;									//otherwise it stays false and it will try again
				}  															
																						
			}

		}
		
		this.currentManagement.sortQuestionsArray();
	}
	
	public boolean addQuestionToArrayAndPickRandomAnswers(int randomId) throws CloneNotSupportedException, IdOutOfRangeException {
		int index = this.currentManagement.getQuestionIndexById(randomId);
		
		Question tempQuestion = this.currentManagement.getQuestion(index);
		if (!(this.currentManagement.getcurrentExam().checkIfQuestionExistsByText(tempQuestion.text))) {//checks if text exits in exam

			if (tempQuestion instanceof AmericanQuestion) {
					
				if(!((AmericanQuestion) tempQuestion).checkIfThereAreEnoughFalseAnswers()){
					return false;
				}//checks if the array of the american question is eligible for adding
				 //if it has less than 4 answers or trueanswers - falseanswers < 4 
				 //since we want to have atleast 4 answers and that 3 of them will be false
				
					int randomAnswerLength = 4 + 2; // 4 answers in a random test + 2 for "more than one que....
					Question tempAmericanQuestion = ((AmericanQuestion)tempQuestion).clone();
					Set<String> pickedAnswers = new Set<String>(randomAnswerLength); //creates two arrays that we will add answers to
					ArrayList<Boolean> pickedAnswersBoolean = new ArrayList<Boolean>();//and exchange the exam arrays in the end
					((AmericanQuestion) tempAmericanQuestion).pickRandomAnswers(pickedAnswers, pickedAnswersBoolean);
					this.currentManagement.getcurrentExam().addQuestion(tempAmericanQuestion);
					return true;

			} else {
				Question tempOpenQuestion = ((OpenQuestion)tempQuestion).clone();
				this.currentManagement.getcurrentExam().addQuestion(tempOpenQuestion);
				return true;
			}
		}
		
		//gets here if text doesn't exist
		return false;	

	}
	
	public static int generateRandomNum(int max, int min) { //static because is used in other classes
		max += 1;
		return (int) (Math.random() * (max - min) + min);
		//Math.random returns a value up to max -1 so we increase the given value by +1 immediately 
		//we decrease the total range by min and then add a flat min to make it a floor of the values
	}
	
}
