package project.model.exceptions;

public class QuestionAlreadyExists extends ManagementException {
	public QuestionAlreadyExists() {
		super("Question already exists");
	}
	
}
