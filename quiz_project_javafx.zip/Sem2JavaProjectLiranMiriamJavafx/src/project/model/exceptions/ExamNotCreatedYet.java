package project.model.exceptions;

public class ExamNotCreatedYet extends ManagementException {
	public ExamNotCreatedYet() {
		super("You haven't created an exam yet");
	}
}
