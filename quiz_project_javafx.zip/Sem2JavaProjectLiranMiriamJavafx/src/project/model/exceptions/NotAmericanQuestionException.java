package project.model.exceptions;

public class NotAmericanQuestionException extends ManagementException {
	public NotAmericanQuestionException() {
		super("The question is not american");
	}
}
