package project.model.exceptions;

public class ManagementException extends Exception{
	public ManagementException(String msg) {
		super(msg);
	}
	public ManagementException() {
		super("General management exception");
	}
	
}
