package project.model.exceptions;

public class ExamSizeTooBigException extends ManagementException {
	public ExamSizeTooBigException() {
		super("There are not enough viable questions");
	}
}
