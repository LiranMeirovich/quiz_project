package project.model.exceptions;

public class IdOutOfRangeException extends ManagementException {
	public IdOutOfRangeException() {
		super("There are not enough false answers");
	}
	
}
