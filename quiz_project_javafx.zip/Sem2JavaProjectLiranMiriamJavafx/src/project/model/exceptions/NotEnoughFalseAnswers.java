package project.model.exceptions;

public class NotEnoughFalseAnswers extends ManagementException {
	public NotEnoughFalseAnswers() {
		super("There are not enough false answers");
	}
}
