package project.model;

import java.io.PrintWriter;

public class OpenQuestion extends Question implements Cloneable{
	private String answer;

	public OpenQuestion(String text) {
		super(text);
	}
	
	public OpenQuestion(String text, String answer) {
		super(text);
		this.answer = answer;
	}
	
	public OpenQuestion clone() throws CloneNotSupportedException{
		return (OpenQuestion)super.clone();
	}
	
	/*public OpenQuestion(OpenQuestion other) {
		super(other);
		this.answer = other.answer;
	}*/

	public String getAnswerText() {
		return this.answer;
	}

	public void setAnswer(String newAnswer) {
		this.answer = newAnswer;
	}
	
	public void removeAnswer() {
		this.answer = null;
		
	}

	
	public boolean equals(Object o) {
		if (!(o instanceof OpenQuestion)) {
			return false;
		}
		if(!super.equals(o)) {
			return false;
		}
		OpenQuestion testQuestion = (OpenQuestion)o;
		
		return this.answer.equals(testQuestion.answer);
	}
	
	@Override
	public String toString() {
		return super.toString() + "The answer is: " + answer + "\n";
	}

	@Override
	public void saveAnswers(PrintWriter pw) {
		pw.println(1);
		pw.println(this.answer);
		
	}

	@Override
	public int countLetters() {
		return this.answer != null ? this.answer.length() : 0;
	}

}
