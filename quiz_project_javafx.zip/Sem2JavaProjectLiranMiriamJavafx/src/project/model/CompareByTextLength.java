package project.model;

import java.util.Comparator;

public class CompareByTextLength implements Comparator<Question> {
	@Override
	public int compare(Question q1, Question q2) {
		int res1 = q1.countLetters();
		int res2 = q2.countLetters();
		
		if (res1 < res2) {
			return -1;
		}
		if (res1 > res2) {
			return 1;
		}
			return 0;
	}
}
		