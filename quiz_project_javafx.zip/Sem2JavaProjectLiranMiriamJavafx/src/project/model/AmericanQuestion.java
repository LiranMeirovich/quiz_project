package project.model;

import java.io.PrintWriter;
import java.util.ArrayList;

@SuppressWarnings("serial")
public class AmericanQuestion extends Question implements Cloneable {
	private Set<String> answers;
	private ArrayList<Boolean> correctAnswers;

	public AmericanQuestion(String text) {
		super(text);

		this.answers = new Set<String>(0);
		this.correctAnswers = new ArrayList<Boolean>();
	}

	public boolean addAnswerToArray(String answerText, boolean correctAnswer) {

		if (this.answers.add(answerText)) {
			this.correctAnswers.add(correctAnswer);
			return true;
		}

		return false;
	}
	
	//Sets
	
	public void setAnswer(int answerNumber, String newAnswer, boolean answerBoolean) {
		
		if (newAnswer == null) {
			this.answers.remove(answerNumber);
			this.correctAnswers.remove(answerNumber);
			return;
		}

		this.answers.set(answerNumber, newAnswer);
		this.correctAnswers.set(answerNumber, answerBoolean);
		
	}
	
	public void setAnswersArray(Set<String> answers, ArrayList<Boolean> correctAnswersArray) {
		this.answers = answers;
		this.correctAnswers = correctAnswersArray;
	}
	
	public void setArrayToFalse() {
		for (int i = 0; i < this.answers.getCurrentSize(); i++) {
			this.correctAnswers.set(i, false);
		}
	}
	
	public void setAnswersClear() {
		while (this.answers.getCurrentSize() != 0) {
			this.answers.remove(0);
		}
	}
	
	//Get
	
	public int getCurrentSize() {
		return this.answers.getLength();
	}
	
	public String getAnswerText(int answerNumber) {
		return this.answers.getArrElement(answerNumber);
	}

	public boolean getCorrectAnswerBoolean(int answerNumber) {
		return this.correctAnswers.get(answerNumber);
	}

	public int getNumOfCorrectAnswers() {
		int res = 0;

		for (int i = 0; i < this.correctAnswers.size(); i++) {
			if (this.correctAnswers.get(i) == true) {
				res++;
			}
		}
		return res;
	}
	
	public Set<String> getAnswerSet() throws CloneNotSupportedException {
		return this.answers.clone(); 
	}

	

	
	//Checks and logic
	
	/*public boolean checkIfAnswerExists(int randomQuestionIndex, Set<String> pickedAnswers) {
		if (pickedAnswers.contains(this.answers.getArrElement(randomQuestionIndex))) {
			return true;
		}

		return false;

	}*/
	
	public boolean checkAnswersArray(String answerText) {
		for (int i = 0; i < this.answers.getCurrentSize(); i++) {
			if (this.answers.getArrElement(i) != null && answerText.equals(this.answers.getArrElement(i))) {
				return true;
			}
		}

		return false;

	}
	
	public boolean checkIfThereAreEnoughFalseAnswers() {
		int numOfTrueAnswers = this.getNumOfCorrectAnswers();// returns amount of answers which are true
		int minNumOfFalseAnswersInQuestion = 3;

		if (numOfTrueAnswers != 0 && this.answers.getCurrentSize() >= 4
				&& this.answers.getCurrentSize() - numOfTrueAnswers >= minNumOfFalseAnswersInQuestion) {// if the amount
																										// of false
																										// answers >= 3
																										// returns true
			// we choose that we want 4 answers for every random question which is why we
			// need to have atleast
			// 3 false answers and 1 true answer or 4 false answers
			return true;
		}

		return false;
	}
	
	//Object methods
	
	@SuppressWarnings("unchecked")
	public AmericanQuestion clone() throws CloneNotSupportedException{
		AmericanQuestion clonedQ = (AmericanQuestion) super.clone();
		clonedQ.answers = (Set<String>) this.answers.clone();
		clonedQ.correctAnswers = (ArrayList<Boolean>) this.correctAnswers.clone();
		return clonedQ;
	}

	
	@Override
	public boolean equals(Object o) {
		if (!(o instanceof AmericanQuestion)) {
			return false;
		}
		if (!super.equals(o)) {
			return false;
		}
		AmericanQuestion testQuestion = (AmericanQuestion) o;

		return testQuestion.answers.equals(this.answers) && testQuestion.correctAnswers.equals(this.correctAnswers);
	}

	@Override
	public String toString() {

		StringBuffer sb = new StringBuffer();
		sb.append("The answers are: \n");

		for (int i = 0; i < this.answers.getCurrentSize(); i++) {
			sb.append(i + 1).append(") ").append(this.answers.getArrElement(i)).append("\t")
					.append(this.correctAnswers.get(i)).append("\n");
		}

		return super.toString() + sb.toString();

	}

	@Override

	public void saveAnswers(PrintWriter pw) {

		pw.println(answers.getCurrentSize());
		for (int i = 0; i < this.answers.getCurrentSize(); i++) {
			pw.println(this.answers.getArrElement(i));
			pw.println(this.correctAnswers.get(i));
		}
	}

	@Override
	public int countLetters() {
		int res = 0;
		for (int i = 0; i < answers.getCurrentSize(); i++) {
			res += answers.getArrElement(i).length();
		}
		return res;
	}

	

	
	//For exam randomization 

	public void pickRandomAnswers(Set<String> pickedAnswers, ArrayList<Boolean> pickedAnswersBoolean) {
		boolean trueAnswerAlreadyExists = false; // Boolean that decides if a true answer already exists
		for (int i = 0; i < pickedAnswers.getLength() - 2; i++) {
			boolean addAnswer = true;
			while (addAnswer) {
				int randomAnswerIndex = RandomizeExam.generateRandomNum(this.answers.getCurrentSize() - 1, 0);// generates
																											// random
																											// index
				// that covers all the answers we have

				if (!trueAnswerAlreadyExists && 
						this.correctAnswers.get(randomAnswerIndex)
						&& pickedAnswers.add(this.answers.getArrElement(randomAnswerIndex))) {
					trueAnswerAlreadyExists = true;
					pickedAnswersBoolean.add(this.correctAnswers.get(randomAnswerIndex));
					addAnswer = false;
				} else if (trueAnswerAlreadyExists && !this.correctAnswers.get(randomAnswerIndex)
						&& pickedAnswers.add(this.answers.getArrElement(randomAnswerIndex))) {// if answer is false adds it
					pickedAnswersBoolean.add(false);
					addAnswer = false;
				}

			}

		}
		
		randomizeFirstAnswer(pickedAnswers, pickedAnswersBoolean); //This makes sure first answer is not always the correct one
		setAnswersArray(pickedAnswers, pickedAnswersBoolean);
		
		Management.addLastTwoAnswersToArray(this); //adds no answer correct / all answers are correct
	}
	
	private void randomizeFirstAnswer(Set<String> pickedAnswers, ArrayList<Boolean> pickedAnswersBoolean) {
		int randomIndex = RandomizeExam.generateRandomNum(3, 0);//choose an index between 0 and current last
		String temp = pickedAnswers.getArrElement(randomIndex);
		boolean tempBoolean = pickedAnswersBoolean.get(randomIndex);
		pickedAnswers.set(randomIndex, pickedAnswers.getArrElement(0));
		pickedAnswersBoolean.set(randomIndex, pickedAnswersBoolean.get(0));
		pickedAnswers.set(0, temp);
		pickedAnswersBoolean.set(0, tempBoolean);
		
	}

	

}
