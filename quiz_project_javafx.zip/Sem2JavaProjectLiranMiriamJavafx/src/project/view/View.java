package project.view;

import java.util.ArrayList;
import javax.swing.JOptionPane;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import project.listeners.*;
import project.model.Set;
import project.view.extras.SpUserInputCases;
import project.view.extras.SpViewQuestions;

public class View implements AbstractQuestionsView {
	public static final int JUMP_SIZE = 8;

	private ArrayList<ViewListenable> allListeners;
	private BorderPane bpMain;

	private ComboBox<String> cmbMenu;
	private Button btnSelectOption;
	private Label lblChoice;

	private HBox hbMenu;
	private SpViewQuestions spQuestionsView;
	private SpUserInputCases spAllCases;
	
	private int choice;

	public View(Stage primaryStage) {
		this.allListeners = new ArrayList<ViewListenable>();

		this.bpMain = new BorderPane();
		this.bpMain.setPadding(new Insets(10));

		this.hbMenu = new HBox();
		this.hbMenu.setSpacing(20);
		this.hbMenu.setAlignment(Pos.CENTER);
		
		this.spAllCases = new SpUserInputCases(allListeners);
		
		Label lblChoice = new Label("Choose an option:");
		this.cmbMenu = new ComboBox<String>();
		cmbMenu.getItems().addAll("Show all questions", "Add Question", "Update wording of question",
				"Update wording for answer", "Delete answer", "Make manual exam", "Make randomized exam", "Clone Exam",
				"Exit and save exam");
		Button btnSelectOption = new Button("Select");
		this.hbMenu.getChildren().addAll(lblChoice, cmbMenu, btnSelectOption);

		this.spQuestionsView = new SpViewQuestions();
		
		this.bpMain.setTop(this.hbMenu);
		this.bpMain.setCenter(this.spQuestionsView);
		this.bpMain.setBottom(this.spAllCases);
		


		btnSelectOption.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent arg0) {

				clearView();

				choice = cmbMenu.getItems().indexOf(cmbMenu.getValue());

				switch (choice) {
				case 0: {
					spQuestionsView.showManagementQuestions(allListeners);
				}
					break;
				case 1: {
					spAllCases.initializeAddQuestion();

				}

					break;
				case 2: {
					spQuestionsView.showManagementQuestions(allListeners);
					spAllCases.initializeUpdateWording();
				}

					break;
				case 3: {
					spQuestionsView.showManagementQuestions(allListeners);
					spAllCases.initializeChangeAnswer();
				}

					break;
				case 4: {
					spQuestionsView.showManagementQuestions(allListeners);
					spAllCases.initializeRemoveAnswer();
				}

					break;
				case 5: {
					allListeners.get(0).viewInitializeExam();
					spAllCases.initializeMakeManualExam();
					spQuestionsView.showManagementQuestions(allListeners);

				}

					break;
				case 6: {
					spAllCases.initializeMakeRandomizedExam();
				}

					break;
				case 7: {
						allListeners.get(0).viewCopyExam();
				}
					break;

				case 8: {
					allListeners.get(0).saveQuestions();
					JOptionPane.showMessageDialog(null, "Program finishing, goodbye");
					primaryStage.close();

				}

					break;
				default:
					break;
				}

			}
		});
		
		Scene scene = new Scene(bpMain, 1000, 775);
		primaryStage.setTitle("Exam program");
		primaryStage.setScene(scene);
		primaryStage.show();

	}
	
	@Override
	public void registerListener(ViewListenable l) {
		allListeners.add(l);
		}

	@Override
	public void clearView() {
		this.spAllCases.disableCases();
		this.spQuestionsView.disableView();
	}
	
	@Override
	public void updateGiveIndex(int index) {
		this.spAllCases.userInput(index, allListeners, choice);
	}
	
	@Override
	public void finishExam() {
		this.clearView();
		this.spQuestionsView.showExamQuestions(allListeners);
		this.allListeners.get(0).viewSaveExam();
	}


	//all functions that show something happened
	@Override
	public void showAddedQuestionSucessfully() {
		JOptionPane.showMessageDialog(null, "Question was added sucessfully");
		this.spAllCases.prepareAddAnswer(allListeners);
	}
 
	
	@Override
	public void showAddedAnswerSuccessfully() {
		JOptionPane.showMessageDialog(null, "Answer was added sucessfully");
		if (!(allListeners.get(0).viewIsCurrentQuestionAmerican())) {//if question is open question resets to add another question 
			this.spAllCases.initializeAddQuestion();
			return;
		}
		//don't need else because of return
		this.spAllCases.addQuestionFinishButtonOn();//Decided to turn on finish button with a function from controller
		//because only controller knows if succeeded to add an answer or not
		
	}
	
	@Override
	public void showTextAlreadyExists() {
		JOptionPane.showMessageDialog(null, "Text already exists");
	}

	@Override
	public void showTextIsEmpty() {
		JOptionPane.showMessageDialog(null, "The text can not be blank!");
	}

	@Override
	public void showQuestionUpdatedSuccessfully() {
		JOptionPane.showMessageDialog(null, "The question's text was updated sucessfully!");
		this.spAllCases.disableCases();
		this.spQuestionsView.disableView();
	}
	
	
	@Override
	public void setAmericanCmbBox(Set<String> answersSet) {
		this.spAllCases.setUpdateAnswerWordingCmbBox(answersSet, choice);
	}

	@Override
	public void showWrongIdInput() {
		JOptionPane.showMessageDialog(null, "Wrong input, please enter a number");
		
	}

	@Override
	public void showIdOutOfRange() {
		JOptionPane.showMessageDialog(null, "The id is out of range");
		
	}


	public void showNotAmericanQuestion() {
		JOptionPane.showMessageDialog(null, "It is not an american question!");
		
	}
	
	public void showQuestionAlreadyExists() {
		JOptionPane.showMessageDialog(null, "This question already exists!");
	}
	
	public void showAnswerUpdatedSuccessfully() {
		JOptionPane.showMessageDialog(null, "Answer updated Sucessfully!");
		clearView();
	}
	
	@Override
	public void showAnswerDeletedSucessfully() {
		JOptionPane.showMessageDialog(null, "Answer removed Sucessfully!");
		clearView();
	}

	//Show for exam
	
	@Override
	public void showAddedExamQuestionSucessfully(int originalIndex) {
		JOptionPane.showMessageDialog(null, "Added question to exam sucessfully");
		
		if (allListeners.get(0).viewIsCurrentExamQuestionAmerican()) {
			this.spAllCases.prepareAddAnswerToManualExam(originalIndex, allListeners);
		}
		else {
			this.spAllCases.finishExamButtonVisible();//if the question was american we only want to show it in the end
			//since we want atleast 1 answer added
		}
	}
	
	@Override
	public void showAddedExamAnswerSuccessfully() {
		JOptionPane.showMessageDialog(null, "Added answer to exam question sucessfully!");
		this.spAllCases.finishAddingAmericanQuestionButtonVisible();
	}


	public void showExamTooBig() {
		JOptionPane.showMessageDialog(null, "The size you choose is too big");
	}
	
	public void showExamSizeMaximum() {
		JOptionPane.showMessageDialog(null, "Exam size too big, finished adding and will show exam questions");
		clearView();
		this.spQuestionsView.showExamQuestions(allListeners);
	}

	public void showExamNotCreated() {
		JOptionPane.showMessageDialog(null, "Exam not created yet");
	}

	public void showExamClonedSucessfully() {
		JOptionPane.showMessageDialog(null, "Exam cloned sucessfully");	
	}


}	
	