package project.view;

import java.io.FileNotFoundException;

import project.listeners.ViewListenable;
import project.model.Set;

public interface AbstractQuestionsView {
	
	void registerListener(ViewListenable l);
	
	void clearView();
	
	void updateGiveIndex(int index);
	
	void finishExam() throws FileNotFoundException;
	
	void showAddedQuestionSucessfully();
	
	void showAddedAnswerSuccessfully();
	
	void showQuestionAlreadyExists();
	
	void showTextAlreadyExists();
	
	void showTextIsEmpty();
	
	void setAmericanCmbBox(Set<String> answersSet);
	
	void showWrongIdInput();
	
    void showIdOutOfRange();

	void showQuestionUpdatedSuccessfully();
	
	void showAnswerUpdatedSuccessfully();
	
	void showAnswerDeletedSucessfully();
	
	void showExamSizeMaximum();
	
	void showAddedExamQuestionSucessfully(int index);
	
	void showAddedExamAnswerSuccessfully();
	
	void showExamTooBig();
	
	void showExamNotCreated();
	
	void showExamClonedSucessfully();

}
