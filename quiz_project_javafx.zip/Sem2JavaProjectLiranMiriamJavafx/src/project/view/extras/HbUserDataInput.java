package project.view.extras;

import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;


public class HbUserDataInput extends HBox{
	private Label lblInformation;
	private TextField tfUserInput;
	
	public HbUserDataInput(String lblName) {
		this.lblInformation = new Label(lblName);
		this.tfUserInput = new TextField();
		this.getChildren().addAll(this.lblInformation, this.tfUserInput);
		this.setSpacing(10);
		
	}

	public String getUserInput() {
		return this.tfUserInput.getText();
	}

	public void clearTextField() {
		this.tfUserInput.setText("");
	}
	
	public void setLblText(String newText) {
		this.lblInformation.setText(newText);
	}
	
}
