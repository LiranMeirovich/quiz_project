package project.view.extras;

import java.util.ArrayList;

import project.view.cases.*;
import javafx.scene.layout.StackPane;
import project.listeners.ViewListenable;
import project.model.Set;

public class SpUserInputCases extends StackPane {
	private AddQuestion gpAddQuestion;
	private UpdateQuestionWording hbUpdateQuestionWording;
	private UpdateAnswerWording gpUpdateAnswerWording;
	private DeleteAnswer gpDeleteAnswer;
	private MakeManualExam gpMakeManualExam;
	private MakeRandomizedExam hbMakeRandomizedExam;
	
	public SpUserInputCases(ArrayList<ViewListenable> allListeners) {
		//uses constructor for each child
		this.gpAddQuestion = new AddQuestion(allListeners);
		this.hbUpdateQuestionWording = new UpdateQuestionWording(allListeners);
		this.gpUpdateAnswerWording = new UpdateAnswerWording(allListeners);
		this.gpDeleteAnswer = new DeleteAnswer(allListeners);
		this.gpMakeManualExam = new MakeManualExam(allListeners);
		this.hbMakeRandomizedExam = new MakeRandomizedExam(allListeners);
		
		this.getChildren().addAll(this.gpAddQuestion, this.hbUpdateQuestionWording, this.gpUpdateAnswerWording
				, this.gpDeleteAnswer, this.gpMakeManualExam, this.hbMakeRandomizedExam);//adds all children
		this.disableCases();
		
	}
	
	//this section is used to prepare the cases or advance them to their next phase
	
	public void initializeAddQuestion() {
		this.gpAddQuestion.initializeAddQuestion();
	}

	public void prepareAddAnswer(ArrayList<ViewListenable> allListeners) {
		this.gpAddQuestion.prepareAddAnswer(allListeners);
	}
	
	public void addQuestionFinishButtonOn() {
		this.gpAddQuestion.finishButtonOn();
	}
	
	public void initializeUpdateWording() {
		this.hbUpdateQuestionWording.initializeUpdateQuestionWording();
	}
	
	public void initializeChangeAnswer() {
		this.gpUpdateAnswerWording.initializeUpdateAnswerWording();
	}
	
	public void initializeRemoveAnswer() {
		this.gpDeleteAnswer.initializeDeleteAnswer();
	}
	
	public void initializeMakeManualExam() {
		this.gpMakeManualExam.initializeMakeManualExam();
	}
	
	public void prepareAddAnswerToManualExam(int index, ArrayList<ViewListenable> allListeners) {
		this.gpMakeManualExam.chooseAmericanQuestionAnswers(index, allListeners);
	}

	public void finishAddingAmericanQuestionButtonVisible() {
		this.gpMakeManualExam.finishAmericanQuestionButtonOn();
	}

	public void finishExamButtonVisible() {
		this.gpMakeManualExam.finishExamButtonOn();
	
	}
	
	public void initializeMakeRandomizedExam() {
		this.hbMakeRandomizedExam.initializeMakeRandomizedExam();
	}
	

	public void disableCases() { //makes all cases invisible so we can have a fresh start when starting a new case
		for (int i = 0; i < this.getChildren().size(); i++) {
			this.getChildren().get(i).setVisible(false);
		}
	}

	public void userInput(int index, ArrayList<ViewListenable> allListeners, int currentCase) { //all use index and listener so we 
																						//choose which one to use depending on case
		if (currentCase == 2) {
			this.hbUpdateQuestionWording.getQuestionTextFromUser(index, allListeners);
		}
		else if (currentCase == 3) {
			this.gpUpdateAnswerWording.getAnswerTextFromUser(index, allListeners);
		}
		else if (currentCase == 4) {
			this.gpDeleteAnswer.userChooseAnswer(index, allListeners);
		}
			
	}
	

	public void setUpdateAnswerWordingCmbBox(Set<String> answersSet, int currentCase) {//all these cases use a combobox and need answer set
																				//so we choose them using current case
		if (currentCase == 3) {
			this.gpUpdateAnswerWording.setAmericanCmbBox(answersSet);
		}
		if (currentCase == 4) {
			this.gpDeleteAnswer.setAmericanCmbBox(answersSet);
		}
		if (currentCase == 5) {
			this.gpMakeManualExam.setAmericanCmbBox(answersSet);
		}
		
	}



	


	
}
