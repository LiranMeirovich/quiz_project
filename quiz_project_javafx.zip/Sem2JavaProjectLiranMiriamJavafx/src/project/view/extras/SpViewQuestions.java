package project.view.extras;

import java.util.ArrayList;

import javafx.scene.layout.StackPane;
import project.listeners.ViewListenable;
import project.view.cases.ShowExamQuestions;
import project.view.cases.ShowManagementQuestions;

public class SpViewQuestions extends StackPane{
	private ShowManagementQuestions bpManagementQuestions;
	private ShowExamQuestions bpExamQuestions;

	public SpViewQuestions() {
		this.bpManagementQuestions = new ShowManagementQuestions();
		this.bpExamQuestions = new ShowExamQuestions();
		
		this.getChildren().addAll(this.bpManagementQuestions, this.bpExamQuestions);
	}
	
	public void disableView() {
		for (int i = 0; i < this.getChildren().size(); i++) {
			this.getChildren().get(i).setVisible(false);
		}
	}
	
	public void showManagementQuestions(ArrayList<ViewListenable> allListeners) {
		this.bpManagementQuestions.initializeQuestions(allListeners);
	}

	public void showExamQuestions(ArrayList<ViewListenable> allListeners) {
		this.bpExamQuestions.initializeQuestions(allListeners);
		
	}
	
}
