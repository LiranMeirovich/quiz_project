package project.view.extras;

import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.HBox;

public class HbQuestionBoolean extends HBox{
	private RadioButton rdoTrue;
	private RadioButton rdoFalse;
	private ToggleGroup tglBoolean;
	
	public HbQuestionBoolean() {
		this.tglBoolean = new ToggleGroup();
		this.rdoTrue = new RadioButton("True");
		this.rdoFalse = new RadioButton("False");
		this.rdoTrue.setToggleGroup(this.tglBoolean);
		this.rdoFalse.setToggleGroup(this.tglBoolean);
		
		this.setSpacing(10);
		this.getChildren().addAll(this.rdoTrue, this.rdoFalse);
	}
	
	public boolean getChoiceText(){
			RadioButton temp = (RadioButton) this.tglBoolean.getSelectedToggle();
			return Boolean.parseBoolean(temp.getText());
	}

	public void setButton() {
		this.rdoTrue.setSelected(true);
	}
	

}
