package project.view.extras;

import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.HBox;

public class HbQuestionType extends HBox{
	private RadioButton rdoAmerican;
	private RadioButton rdoOpen;
	private ToggleGroup tglType;
	
	public HbQuestionType() {
		this.tglType = new ToggleGroup();
		this.rdoAmerican = new RadioButton("American Question");
		this.rdoOpen = new RadioButton("Open Question");
		this.rdoAmerican.setToggleGroup(this.tglType);
		this.rdoOpen.setToggleGroup(this.tglType);
		
		this.setSpacing(10);
		this.getChildren().addAll(this.rdoAmerican, this.rdoOpen);
	}
	
	public String getChoiceText(){
			RadioButton temp = (RadioButton) this.tglType.getSelectedToggle();
			return temp.getText();
	}

	public void setButton() {
		this.rdoAmerican.setSelected(true);
	}
	
	
}
