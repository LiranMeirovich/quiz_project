package project.view.cases;

import java.util.ArrayList;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import project.listeners.ViewListenable;
import project.model.Set;
import project.view.extras.HbUserDataInput;

public class MakeManualExam extends GridPane {
	private HbUserDataInput hbQuestionsData;

	private Label lblSelectAnswer;
	private ComboBox<String> cmbAmericanAnswers;

	private Button btnGetId;
	private Button btnSelectAnswer;
	private Button btnFinishAmericanQuestion;
	private Button btnFinishExam;

	public MakeManualExam(ArrayList<ViewListenable> allListeners) {
		this.lblSelectAnswer = new Label("Select Answer:");
		this.cmbAmericanAnswers = new ComboBox<String>();
		this.hbQuestionsData = new HbUserDataInput("Enter question ID:");
		this.btnGetId = new Button("Get ID");
		this.btnSelectAnswer = new Button("Select Answer");

		this.btnFinishAmericanQuestion = new Button("Finish Question");
		this.btnFinishExam = new Button("Finish Exam");

		this.add(this.hbQuestionsData, 0, 1);
		this.add(this.lblSelectAnswer, 0, 0);
		this.add(this.cmbAmericanAnswers, 0, 1);
		this.add(this.btnGetId, 2, 1);
		this.add(this.btnSelectAnswer, 2, 1);
		this.add(this.btnFinishAmericanQuestion, 3, 1);
		this.add(this.btnFinishExam, 4, 1);

		this.setHgap(10);
		this.setVgap(10);
		this.setAlignment(Pos.CENTER);

		this.setPadding(new Insets(10));

		btnGetId.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent arg0) {
				allListeners.get(0).viewAddQuestionToExam(hbQuestionsData.getUserInput());
				hbQuestionsData.clearTextField();
			}
		});
		
		btnFinishAmericanQuestion.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent arg0) {
				allListeners.get(0).viewAddLastTwoAnswers();//adds all answers true / not enought answers true
				initializeMakeManualExam(); //resets to get id from user
				finishExamButtonOn();//exam already has one question so we let finish exam button on
			}
		});
		
		btnFinishExam.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent arg0) {
				allListeners.get(0).viewFinishManualExam();
			}
		});
	}

	public void initializeMakeManualExam() {
		for (int i = 0; i < this.getChildren().size(); i++) {
			this.getChildren().get(i).setVisible(false); //sets all of the children to invisible
		}
		this.setVisible(true);
		
		this.hbQuestionsData.clearTextField();
		this.btnGetId.setVisible(true); //turns on only the ones we need
		this.hbQuestionsData.setVisible(true);
	}
	
	public void finishExamButtonOn() {
		if (!(this.btnFinishExam.isVisible())) {
			this.btnFinishExam.setVisible(true);
		}
	}
	
	public void finishAmericanQuestionButtonOn() {//We want to have atleast 1 answer for a question
		if (!(this.btnFinishAmericanQuestion.isVisible())) {
			this.btnFinishAmericanQuestion.setVisible(true);
		}
		
	}

	public void setAmericanCmbBox(Set<String> answersSet) {
		this.cmbAmericanAnswers.getItems().clear();// clears all labels
		for (int i = 0; i < answersSet.getCurrentSize(); i++) {
			this.cmbAmericanAnswers.getItems().add(answersSet.getArrElement(i));// changes each label
			this.cmbAmericanAnswers.getSelectionModel().select(0); // selects the first answer as default
		}

	}

	public void chooseAmericanQuestionAnswers(int index, ArrayList<ViewListenable> allListeners) {
	
			allListeners.get(0).viewSetAmericanAnswers(index);
			this.btnFinishExam.setVisible(false); //to make sure the question will have one answer atleast
			this.hbQuestionsData.setVisible(false);
			this.btnGetId.setVisible(false);
			this.lblSelectAnswer.setVisible(true);
			this.btnSelectAnswer.setVisible(true);
			this.cmbAmericanAnswers.setVisible(true);
		
		this.btnSelectAnswer.setOnAction(new EventHandler<ActionEvent>() {//needs to be in the function to get index
													//of question from management so it can put its answer to new exam question

			@Override
			public void handle(ActionEvent arg0) {
				int answerChoice = cmbAmericanAnswers.getItems().indexOf(cmbAmericanAnswers.getValue());
				allListeners.get(0).viewAddAnswerToExam(index, answerChoice);
			}
		});
	}



	

}
