package project.view.cases;


import java.util.ArrayList;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import project.listeners.ViewListenable;
import project.view.extras.HbUserDataInput;

public class UpdateQuestionWording extends HBox{
	
	private HbUserDataInput hbQuestionsData;
	
	private Button btnGetId;
	private Button btnNewText;
	
	public UpdateQuestionWording(ArrayList<ViewListenable> allListeners) {
		
		this.hbQuestionsData = new HbUserDataInput("Enter question ID:");
		this.btnGetId = new Button("Get ID");
		this.btnNewText = new Button("Update Text");
		
		
		this.setPadding(new Insets(35, 0, 0, 0));
		this.setSpacing(10);
		this.setAlignment(Pos.TOP_CENTER);
		this.getChildren().addAll(this.hbQuestionsData, this.btnGetId, this.btnNewText);
		
		btnGetId.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent arg0) {
				allListeners.get(0).viewGiveIndex(hbQuestionsData.getUserInput());
				hbQuestionsData.clearTextField();
			}
		});
		
		
	}
	
	public void initializeUpdateQuestionWording() {
		this.setVisible(true);
		this.hbQuestionsData.clearTextField();
		this.hbQuestionsData.setLblText("Enter question ID:");
		this.setVisible(true);
		this.btnGetId.setVisible(true);
		this.btnNewText.setVisible(false);
	}
	
	

	public void getQuestionTextFromUser(int index, ArrayList<ViewListenable> allListeners) {
		this.hbQuestionsData.setLblText("Enter new text:");
		this.btnGetId.setVisible(false);
		this.btnNewText.setVisible(true);
		HbUserDataInput temp = this.hbQuestionsData;//we need a way to access the data the user inputs
		
		btnNewText.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent arg0) {
				allListeners.get(0).viewChangeQuestion(temp.getUserInput(), index);
			}
		});
	}
	
	
	
}
