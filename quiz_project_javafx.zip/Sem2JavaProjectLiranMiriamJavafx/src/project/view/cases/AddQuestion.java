package project.view.cases;

import java.util.ArrayList;
import project.model.*;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.layout.GridPane;
import project.view.extras.HbQuestionBoolean;
import project.view.extras.HbQuestionType;
import project.view.extras.HbUserDataInput;
import project.listeners.ViewListenable;

public class AddQuestion extends GridPane{
	private HbUserDataInput hbQuestionsData;
	private HbQuestionType hbQuestionChoice;
	private HbQuestionBoolean hbQuestionBooleanChoice;
	
	private Button btnAddQuestionText;
	private Button btnAddAmericanAnswer;
	private Button btnFinishAmericanAnswer;
	private Button btnAddOpenAnswer;
	
	public AddQuestion(ArrayList<ViewListenable> allListeners) {
		this.hbQuestionsData = new HbUserDataInput("Enter question text:");
		this.hbQuestionChoice = new HbQuestionType();
		this.hbQuestionBooleanChoice = new HbQuestionBoolean();
		
		this.btnAddQuestionText = new Button("Add question");
		this.btnAddAmericanAnswer = new Button("Add answer");
		this.btnFinishAmericanAnswer = new Button("Finish Question");
		this.btnAddOpenAnswer = new Button("Add answer");
		
		this.add(hbQuestionChoice, 0, 0);
		this.add(hbQuestionBooleanChoice, 0, 0);
		this.add(hbQuestionsData, 0, 1);
		this.add(btnAddQuestionText, 1, 1);
		this.add(btnAddAmericanAnswer, 1, 1);
		this.add(btnAddOpenAnswer, 1, 1);
		this.add(btnFinishAmericanAnswer, 2, 1);
		
		this.setHgap(10);
		this.setVgap(10);
		this.setAlignment(Pos.CENTER);
		
		this.setPadding(new Insets(10));
		
		btnAddQuestionText.setOnAction(new EventHandler<ActionEvent>() {
			
			@Override
			public void handle(ActionEvent arg0) {
				String text = hbQuestionsData.getUserInput(); //gets question text
				String type = hbQuestionChoice.getChoiceText(); //get open/american as string
				
				allListeners.get(0).viewAddQuestion(text, type); //tries to add question to management
				
				hbQuestionsData.clearTextField();//clears text of textfield
			}
		});
		
		btnAddAmericanAnswer.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent arg0) {
				String text = hbQuestionsData.getUserInput(); //gets answer text
				boolean answerBoolean = hbQuestionBooleanChoice.getChoiceText(); //gets boolean true/false depending on user choice
				hbQuestionsData.clearTextField();
				
				allListeners.get(0).viewAddAnswerAmerican(text, answerBoolean);//attempts to add american question answer
			}
		});
		
		btnAddOpenAnswer.setOnAction(new EventHandler<ActionEvent>() {		
			
			@Override
			public void handle(ActionEvent arg0) {
				String text = hbQuestionsData.getUserInput();//answer text
				hbQuestionsData.clearTextField(); 
				
				allListeners.get(0).viewAddAnswer(text);//attempts to add open question answer
			}
		});
		
		btnFinishAmericanAnswer.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent arg0) {
				initializeAddQuestion(); //just returns to add question on finish
			}
		});
		
	}
	
	
	public void initializeAddQuestion() {
		this.setVisible(true);
		this.hbQuestionsData.setLblText("Enter question text:");
		this.hbQuestionChoice.setButton(); //We want to have one selected whenever we initialize this case
		this.hbQuestionBooleanChoice.setButton(); 
		this.btnAddAmericanAnswer.setVisible(false);//turn all what we don't need invisible
		this.btnAddOpenAnswer.setVisible(false);
		this.btnFinishAmericanAnswer.setVisible(false);
		this.hbQuestionBooleanChoice.setVisible(false);
		
		this.hbQuestionChoice.setVisible(true);
		this.btnAddQuestionText.setVisible(true);//just need this button for the first part
		
		
	}

	public void prepareAddAnswer(ArrayList<ViewListenable> allListeners) {
		this.btnAddQuestionText.setVisible(false); //makes irrelevant buttons invisible
		this.hbQuestionChoice.setVisible(false);
		this.hbQuestionsData.setLblText("Enter answer text:");
		
		if (allListeners.get(0).viewIsCurrentQuestionAmerican()) { //checks type of question
			this.hbQuestionBooleanChoice.setVisible(true); //makes relevant buttons visible
			this.btnAddAmericanAnswer.setVisible(true);
			return;
		}
		//acts as else thanks to return
		this.btnAddOpenAnswer.setVisible(true);
		
	}


	public void finishButtonOn() {
		if (!(this.btnFinishAmericanAnswer.isVisible())) {//checks if turned on already
			this.btnFinishAmericanAnswer.setVisible(true);
		}
		
	}
	
	
}
