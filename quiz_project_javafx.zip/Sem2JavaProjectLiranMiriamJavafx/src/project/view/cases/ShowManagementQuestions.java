package project.view.cases;

import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import project.listeners.ViewListenable;


import java.util.ArrayList;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

public class ShowManagementQuestions extends BorderPane {
	protected final int MAX_LABELS_TO_SHOW = 8; //View should know how much to jump since it depends on the size of the view
	
	protected int currentQuestionsIndex;
	
	protected ArrayList<Label> questionsLabel;
	protected GridPane gpQuestionsView;
	protected Button btnGoLeft;
	protected Button btnGoRight;

	public ShowManagementQuestions() {
		this.questionsLabel = new ArrayList<Label>(); //will hold all our questions labels
		for (int i = 0; i < MAX_LABELS_TO_SHOW; i++) {//initializes all the our labels
			this.questionsLabel.add(new Label(""));
		}
		
		this.gpQuestionsView = new GridPane();
		
		for (int i = 0; i < questionsLabel.size(); i = i + 2) { //initializes the gridpane with all the labels
			this.gpQuestionsView.add(this.questionsLabel.get(i), 0, i); //this lets us only need to update label text every time we change
			this.gpQuestionsView.add(this.questionsLabel.get(i+1), 1, i); //the viewed questions
		}
		
		this.gpQuestionsView.setAlignment(Pos.TOP_CENTER);
		this.gpQuestionsView.setHgap(50);
		this.gpQuestionsView.setVgap(8);
		this.setPadding(new Insets(29));
		
		this.setPadding(new Insets(10));
		
		this.btnGoLeft = new Button("<--"); //Will be used to show the previous set of questions
		this.btnGoRight = new Button("-->"); //Will be used to show the next set of questions
		
		this.setLeft(this.btnGoLeft); //set the children
		this.setRight(this.btnGoRight);
		this.setCenter(this.gpQuestionsView);
		
		this.setAlignment(this.btnGoLeft, Pos.CENTER_LEFT); //push the button to middle left
		this.setAlignment(this.btnGoRight, Pos.CENTER_RIGHT); //push button to middle right
		this.setMargin(this.gpQuestionsView, new Insets(20,0,0,45)); //push questions text to center
		
		this.setVisible(false);
		
		
	}
	
	public void initializeQuestions(ArrayList<ViewListenable> allListeners) {
		this.setVisible(true); //Makes questions visible
		int capacity = allListeners.get(0).viewGetCapacity();//gets the length of the questions array in managment
		this.currentQuestionsIndex = 0; //resets counter to 0 so we start from the start of the questions array
		printQuestions(allListeners.get(0).viewShowAllQuestions(currentQuestionsIndex, MAX_LABELS_TO_SHOW));//goes to change the labels
		
		btnGoRight.setOnAction(new EventHandler<ActionEvent>() {
			

			@Override
			public void handle(ActionEvent arg0) {
				if (currentQuestionsIndex + MAX_LABELS_TO_SHOW < capacity) {
					currentQuestionsIndex += MAX_LABELS_TO_SHOW; //changes starting index of labels
					printQuestions(allListeners.get(0).viewShowAllQuestions(currentQuestionsIndex, MAX_LABELS_TO_SHOW));
				}
			}
		});
		
		btnGoLeft.setOnAction(new EventHandler<ActionEvent>() {
			
			
			@Override
			public void handle(ActionEvent arg0) {
				if (currentQuestionsIndex - MAX_LABELS_TO_SHOW >= 0) {
					currentQuestionsIndex -= MAX_LABELS_TO_SHOW; //changes starting index of labels
					printQuestions(allListeners.get(0).viewShowAllQuestions(currentQuestionsIndex, MAX_LABELS_TO_SHOW));
				}
			}
		});
		
	}
	
	public void printQuestions(ArrayList<String> questions) {
		
		for (int i = 0; i < this.questionsLabel.size(); i++) {
			if (i <questions.size()) {
				this.questionsLabel.get(i).setText(questions.get(i));//changes label text to the questions text
			}
			else {
				this.questionsLabel.get(i).setText("");//resets the label incase we're out of questions to add
			}
		}
	}
	
	/*private void showNextQuestions(String nextOrPrevious) {
		int capacity;
		int currentQuestionsIndex = this.gpQuestions.getCurrentQuestionsIndex();
		
		capacity = allListeners.get(0).viewGetQuestionsSize();

		if (nextOrPrevious.equals("Next") && capacity > currentQuestionsIndex + MAX_LABELS_TO_SHOW) {
			this.gpQuestions.setCurrentQuestionsIndex(currentQuestionsIndex + MAX_LABELS_TO_SHOW);
		} else if (nextOrPrevious.equals("Previous") && currentQuestionsIndex - MAX_LABELS_TO_SHOW >= 0) {
			this.gpQuestions.setCurrentQuestionsIndex(currentQuestionsIndex - MAX_LABELS_TO_SHOW);
		} else {
			return;
		}
		this.gpQuestions.getChildren().clear();

		allListeners.get(0).viewShowAllQuestions(this.gpQuestions.getCurrentQuestionsIndex());

	}*/

}
