package project.view.cases;

import java.util.ArrayList;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import project.listeners.ViewListenable;

public class ShowExamQuestions extends ShowManagementQuestions{

	public ShowExamQuestions() {
		super();
	}
	
	@Override //the only difference between show management and exam is this function, so we just override it
	public void initializeQuestions(ArrayList<ViewListenable> allListeners) {
		this.setVisible(true); //Makes questions visible
		int capacity = allListeners.get(0).viewGetExamSize();//gets the length of the questions array in exam
		this.currentQuestionsIndex = 0; //resets counter to 0 so we start from the start of the questions array
		printQuestions(allListeners.get(0).viewShowExamQuestions(currentQuestionsIndex, MAX_LABELS_TO_SHOW));//goes to change the labels
		
		btnGoRight.setOnAction(new EventHandler<ActionEvent>() {
			

			@Override
			public void handle(ActionEvent arg0) {
				if (currentQuestionsIndex + MAX_LABELS_TO_SHOW < capacity) {
					currentQuestionsIndex += MAX_LABELS_TO_SHOW; //changes starting index of labels
					printQuestions(allListeners.get(0).viewShowExamQuestions(currentQuestionsIndex, MAX_LABELS_TO_SHOW));
				}
			}
		});
		
		btnGoLeft.setOnAction(new EventHandler<ActionEvent>() {
			
			
			@Override
			public void handle(ActionEvent arg0) {
				if (currentQuestionsIndex - MAX_LABELS_TO_SHOW >= 0) {
					currentQuestionsIndex -= MAX_LABELS_TO_SHOW; //changes starting index of labels
					printQuestions(allListeners.get(0).viewShowExamQuestions(currentQuestionsIndex, MAX_LABELS_TO_SHOW));
				}
			}
		});
		
	}

}
