package project.view.cases;

import java.util.ArrayList;
import java.util.Iterator;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import project.listeners.ViewListenable;
import project.model.Set;
import project.view.extras.HbQuestionBoolean;
import project.view.extras.HbUserDataInput;

public class UpdateAnswerWording extends GridPane {
	private HbUserDataInput hbQuestionsData;

	private HbQuestionBoolean hbQuestionBoolean;
	private Label lblSelectAnswer;
	private Button btnGetId;
	private ComboBox<String> cmbAmericanAnswers;
	private Button btnSelectAnswer;
	private Button btnNewText;

	public UpdateAnswerWording(ArrayList<ViewListenable> allListeners) {

		this.lblSelectAnswer = new Label("Select Answer:");
		this.hbQuestionBoolean = new HbQuestionBoolean();
		this.cmbAmericanAnswers = new ComboBox<String>();
		this.hbQuestionsData = new HbUserDataInput("Enter question ID:");
		this.btnGetId = new Button("Get ID");
		this.btnSelectAnswer = new Button("Select Answer");
		this.btnNewText = new Button("Update Text");

		this.add(this.hbQuestionBoolean, 0, 0);
		this.add(this.hbQuestionsData, 0, 1);
		this.add(this.lblSelectAnswer, 0, 0);
		this.add(this.cmbAmericanAnswers, 0, 1);
		this.add(this.btnGetId, 2, 1);
		this.add(this.btnSelectAnswer, 2, 1);
		this.add(this.btnNewText, 2, 1);
		
		this.setHgap(10);
		this.setVgap(10);
		this.setAlignment(Pos.CENTER);
		
		this.setPadding(new Insets(10));
		
		btnGetId.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent arg0) {
				allListeners.get(0).viewGiveIndex(hbQuestionsData.getUserInput());
				hbQuestionsData.clearTextField();
			}
		});

	}
	
	public void initializeUpdateAnswerWording() {
		this.setVisible(true);
		for (int i = 0; i < this.getChildren().size(); i++) {
			this.getChildren().get(i).setVisible(false); //sets all of the children to invisible
		}
		
		this.btnGetId.setVisible(true);//turns on only the ones we need
		this.hbQuestionsData.setVisible(true);
		this.hbQuestionsData.setLblText("Enter question ID:");
		
		
	}

	public void setAmericanCmbBox(Set<String> answersSet) {
		this.cmbAmericanAnswers.getItems().clear();//clears all labels
		for (int i = 0; i < answersSet.getCurrentSize(); i++) {
			this.cmbAmericanAnswers.getItems().add(answersSet.getArrElement(i));//changes each label 
			this.cmbAmericanAnswers.getSelectionModel().select(0); //selects the first answer as default
		}

	}

	public void getAnswerTextFromUser(int index, ArrayList<ViewListenable> allListeners) {
		this.btnGetId.setVisible(false);
		if (allListeners.get(0).viewIsAmerican(index)) {
			this.hbQuestionsData.setVisible(false); 
			this.cmbAmericanAnswers.setVisible(true);
			this.btnSelectAnswer.setVisible(true);
			this.lblSelectAnswer.setVisible(true);
			
			allListeners.get(0).viewSetAmericanAnswers(index);//controller will input the answers into the combobox
			
			this.btnSelectAnswer.setOnAction(new EventHandler<ActionEvent>() {//we put the button inside the if so it can get answerChoice
				//if has to be taken anyways for it to even show

				@Override 
				public void handle(ActionEvent arg0) {
					
					btnSelectAnswer.setVisible(false);
					lblSelectAnswer.setVisible(false);
					cmbAmericanAnswers.setVisible(false);
					
					btnNewText.setVisible(true);
					hbQuestionsData.setVisible(true);
					hbQuestionsData.setLblText("Enter answer text:");
					hbQuestionBoolean.setVisible(true);
					hbQuestionBoolean.setButton();
					
				}
			});
			
			this.btnNewText.setOnAction(new EventHandler<ActionEvent>() {//if american question is chosen the button
				//will have a different functionality than if an open one was chosen

				@Override 
				public void handle(ActionEvent arg0) {
					int answerChoice = cmbAmericanAnswers.getItems().indexOf(cmbAmericanAnswers.getValue());
					boolean answerBoolean = hbQuestionBoolean.getChoiceText(); //gets boolean true/false depending on user choice
					allListeners.get(0).viewChangeAnswerAmerican(hbQuestionsData.getUserInput(), index, answerChoice, answerBoolean);
					hbQuestionsData.clearTextField();
				}
			});
		}
		
		else {
			this.hbQuestionsData.setLblText("Enter answer text:");
			this.btnNewText.setVisible(true);
			
			this.btnNewText.setOnAction(new EventHandler<ActionEvent>() {//if american question is chosen the button
				//will have a different functionality than if an open one was chosen

				@Override 
				public void handle(ActionEvent arg0) {
					allListeners.get(0).viewChangeAnswer(hbQuestionsData.getUserInput(), index);
					hbQuestionsData.clearTextField();
				}
			});
		}
		
		
		
	}


}