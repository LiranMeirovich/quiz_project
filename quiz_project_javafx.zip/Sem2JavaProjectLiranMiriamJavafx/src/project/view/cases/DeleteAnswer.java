package project.view.cases;

import java.util.ArrayList;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import project.listeners.ViewListenable;
import project.model.Set;
import project.view.extras.HbUserDataInput;

public class DeleteAnswer extends GridPane {
	private HbUserDataInput hbQuestionsData;
	
	private ComboBox<String> cmbAmericanAnswers;
	private Button btnSelectAnswer;
	
	private Label lblSelectAnswer;
	private Button btnGetId;
	
	public DeleteAnswer(ArrayList<ViewListenable> allListeners) {
		
		this.hbQuestionsData = new HbUserDataInput("Enter question ID:");
		
		this.cmbAmericanAnswers = new ComboBox<String>();
		this.btnSelectAnswer = new Button("Select");
		
		this.btnGetId = new Button("Get ID");
		this.lblSelectAnswer = new Label("Select Answer:");
		
		
		this.add(this.hbQuestionsData, 0, 1);
		this.add(this.lblSelectAnswer, 0, 0);
		this.add(this.cmbAmericanAnswers, 0, 1);
		this.add(this.btnGetId, 2, 1);
		this.add(this.btnSelectAnswer, 2, 1);
		
		this.setHgap(10);
		this.setVgap(10);
		this.setAlignment(Pos.CENTER);
		
		this.setPadding(new Insets(10));
		
		btnGetId.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent arg0) {
				allListeners.get(0).viewGiveIndex(hbQuestionsData.getUserInput());
				hbQuestionsData.clearTextField();
			}
		});
	}
	
	
	
	public void initializeDeleteAnswer() {
		this.setVisible(true);
		for (int i = 0; i < this.getChildren().size(); i++) {
			this.getChildren().get(i).setVisible(false); //sets all of the children to invisible
		}
		
		this.hbQuestionsData.clearTextField();
		this.btnGetId.setVisible(true);//turns on only the ones we need
		this.hbQuestionsData.setVisible(true);
	}
	
	public void setAmericanCmbBox(Set<String> answersSet) {
		this.cmbAmericanAnswers.getItems().clear();//clears all labels
		for (int i = 0; i < answersSet.getCurrentSize(); i++) {
			this.cmbAmericanAnswers.getItems().add(answersSet.getArrElement(i));//changes each label 
			this.cmbAmericanAnswers.getSelectionModel().select(0); //selects the first answer as default
		}

	}

	public void userChooseAnswer(int index, ArrayList<ViewListenable> allListeners) {
		if (allListeners.get(0).viewIsAmerican(index)) {
			allListeners.get(0).viewSetAmericanAnswers(index);//controller updates combobox labels
			this.cmbAmericanAnswers.setVisible(true);
			this.btnSelectAnswer.setVisible(true);
			this.lblSelectAnswer.setVisible(true);
			
			this.btnGetId.setVisible(false);
			this.hbQuestionsData.setVisible(false);
			
			
		}
		else {
			allListeners.get(0).viewRemoveAnswerOpen(index);
		}
		
		this.btnSelectAnswer.setOnAction(new EventHandler<ActionEvent>() {//button will only show if american
														//we need it in the function so we can get index of question

			@Override 
			public void handle(ActionEvent arg0) {
				int answerChoice = cmbAmericanAnswers.getItems().indexOf(cmbAmericanAnswers.getValue());
				allListeners.get(0).viewRemoveAnswerAmerican(index, answerChoice);
			}
		});
		
	}
	
}
