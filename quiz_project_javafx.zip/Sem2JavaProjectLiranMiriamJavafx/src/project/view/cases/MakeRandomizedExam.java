package project.view.cases;

import java.util.ArrayList;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import project.listeners.ViewListenable;
import project.view.extras.HbUserDataInput;

public class MakeRandomizedExam extends HBox{
	private HbUserDataInput	hbExamSize;
	private Button btnCreateExam;
	
	public MakeRandomizedExam(ArrayList<ViewListenable> allListeners) {
	
		this.hbExamSize = new HbUserDataInput("Enter amount of desired questions:");
		this.btnCreateExam = new Button("Create exam");
		
		this.setPadding(new Insets(35, 0, 0, 0));
		this.setSpacing(10);
		this.setAlignment(Pos.TOP_CENTER);
		this.getChildren().addAll(this.hbExamSize, this.btnCreateExam);
		
		this.btnCreateExam.setOnAction(new EventHandler<ActionEvent>() {
			
			@Override
			public void handle(ActionEvent arg0) {
				allListeners.get(0).viewMakeRandomizedExam(hbExamSize.getUserInput());
			}
		});
	}
	
	public void initializeMakeRandomizedExam() {
		this.hbExamSize.clearTextField();
		this.setVisible(true);
	}
	
	
}
