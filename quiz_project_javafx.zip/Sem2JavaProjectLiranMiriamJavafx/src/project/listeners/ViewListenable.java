package project.listeners;

import java.io.FileNotFoundException;
import java.util.ArrayList;

import project.model.Set;
import project.model.exceptions.ExamNotCreatedYet;
import project.model.exceptions.ExamSizeTooBigException;
import project.model.exceptions.IdOutOfRangeException;
import project.model.exceptions.QuestionAlreadyExists;

public interface ViewListenable {
	ArrayList<String> viewShowAllQuestions(int startingIndex, int jumpRange);
	
	int viewGetCapacity();
	
	void viewGiveIndex(String id);
	
	void viewAddQuestion(String text, String type);

	void viewAddAnswer(String text);

	void viewAddAnswerAmerican(String text, boolean answerBoolean);

	void viewChangeQuestion(String text, int currentIndex);

	void viewChangeAnswer(String text, int currentIndex);

	void viewChangeAnswerAmerican(String text, int currentIndex, int answerIndex, boolean answerBoolean);

	void viewRemoveAnswerOpen(int currentIndex);

	void viewRemoveAnswerAmerican(int currentIndex, int answerIndex);

	void viewAddQuestionToExam(String id);

	void viewInitializeExam();

	void viewAddAnswerToExam(int currentIndex, int answerIndex);

	int viewGetExamSize();

	ArrayList<String> viewShowExamQuestions(int startingIndex, int jumpSize);

	void viewMakeRandomizedExam(String string);

	void viewCopyExam();

	void viewSaveExam();

	boolean viewIsAmerican(int index);

	void viewSetAmericanAnswers(int index);

	boolean viewIsCurrentQuestionAmerican();

	boolean viewIsCurrentExamQuestionAmerican();

	void viewFinishManualExam();

	void saveQuestions();

	void viewAddLastTwoAnswers();
	
}
