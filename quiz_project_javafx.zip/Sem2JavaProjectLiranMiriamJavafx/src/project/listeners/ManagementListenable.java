package project.listeners;

import java.util.ArrayList;

import project.model.Set;

public interface ManagementListenable {

	void modelUpdateTextIsEmpty();

	void modelUpdateAddedQuestion(String type);

	void modelTextAlreadyExists();

	void modelUpdateAnswerAdded();
	
	void modelUpdateExamAnswerAdded();

	void modelUpdateQuestionChanged();
	
	void modelUpdateAnswerChanged();

	void modelUpdateAnswerRemoved();
	
}
