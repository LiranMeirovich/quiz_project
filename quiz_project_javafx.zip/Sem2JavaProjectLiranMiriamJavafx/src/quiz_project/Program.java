package quiz_project;

import javafx.application.Application;
import javafx.stage.Stage;
import project.controller.Controller;
import project.model.Management;
import project.view.*;

public class Program extends Application{

	public static void main(String[] args) {
		launch(args);
	}
	
	@Override
	public void start(Stage primaryStage) throws Exception {
		Management theModel = new Management();
		View theView1 = new View(primaryStage);
		Controller controller1 = new Controller(theModel, theView1);
		
		
	}

}
